# Redshirt
Adds iconic Star Trek Redshirt suit to mod MoreSuits for Lethal Company
But because this mod did so well and because not everybody is cut out to be a Redshirt ;) I've added two more bonus suits!
Now you can have yourself an Away Team. ;)  FYI, this is the FINAL version, unless for compatibility/playability reasons I'm required to update it.
Added 6 more suits. Feel free to remove whatever you don't need/want since I shouldn't be updating this. Six suits are Ensign and Lieutenant Ranks of each Department color. 
Boss, err I mean, Lead those Lower Decks! Screenshots below! Thank you all for downloading!
If you can't see the screenshots below go here: https://github.com/saintanthony/Redshirt#

<p align="center">
	<img src="https://media.discordapp.net/attachments/456306509266157599/1199268814165123143/redshirtpreview.png?ex=65c1ed1e&is=65af781e&hm=9bb462f7b031c886657bbecbe88139565ac63181e21b004880c391cf097a6b63&=&format=webp&quality=lossless&width=318&height=676">
	<img src="https://media.discordapp.net/attachments/456306509266157599/1199268816283246644/Lieutenant_Redshirt_preview.png?ex=65c1ed1f&is=65af781f&hm=fd7ebade406851266832604142fa83284595f83dade39247bc2d52fcff4f8f40&=&format=webp&quality=lossless&width=300&height=675">
	<img src="https://media.discordapp.net/attachments/456306509266157599/1199268815217885274/Ensign_Redshirt_preview.png?ex=65c1ed1e&is=65af781e&hm=adc649e395f3957e8cf45cea837547a078dae6ed3bc9e6faaa2ec0cc0157bd3c&=&format=webp&quality=lossless&width=303&height=675">
	<img src="https://media.discordapp.net/attachments/456306509266157599/1199268814458736640/blueshirtpreview.png?ex=65c1ed1e&is=65af781e&hm=40d8b3002a5a210a0894a9c4cb3ca1cd3378a53d24448d0b77b8673808bd0b2a&=&format=webp&quality=lossless&width=329&height=675">
	<img src="https://media.discordapp.net/attachments/456306509266157599/1199268815721222214/Lieutenant_Blueshirt_preview.png?ex=65c1ed1f&is=65af781f&hm=1b31889a2862aac16eb9e3312b46736eaa36f9b3bfbb1f08ac1ce1b4445a425e&=&format=webp&quality=lossless&width=330&height=676">
	<img src="https://media.discordapp.net/attachments/456306509266157599/1199268814727159880/Ensign_Blueshirt_preview.png?ex=65c1ed1e&is=65af781e&hm=a66443333fc971d1a2ebabe0bd9d26d6044f09af6667f154bd52ebe93aafd0c7&=&format=webp&quality=lossless&width=322&height=675">
	<img src="https://media.discordapp.net/attachments/456306509266157599/1199268815473745950/goldshirtpreview.png?ex=65c1ed1e&is=65af781e&hm=558f69eeb806f622ba96af6ceb40e85219c4cc99b8155fcd2c8c2cac88c3bad0&=&format=webp&quality=lossless&width=305&height=676">
	<img src="https://media.discordapp.net/attachments/456306509266157599/1199268816002220072/Lieutenant_Goldshirt_preview.png?ex=65c1ed1f&is=65af781f&hm=eac463cf985bb5acefbb5a0a015fcbaed05acf7e36ba4451c1c42498a772cefa&=&format=webp&quality=lossless&width=321&height=676">
	<img src="https://media.discordapp.net/attachments/456306509266157599/1199268815003996270/Ensign_Goldshirt_preview.png?ex=65c1ed1e&is=65af781e&hm=7cfd4fd668d04df78b84d1e5242e7bea223e594dd0c8517c097c2a347ed88219&=&format=webp&quality=lossless&width=312&height=676">
</p>


[Redshirt](https://github.com/saintanthony/Redshirt/blob/main/redshirtpreview.png "Redshirt")
[Blueshirt]( https://github.com/saintanthony/Redshirt/blob/main/blueshirtpreview.png "Blueshirt")
[Goldshirt]( https://github.com/saintanthony/Redshirt/blob/main/goldshirtpreview.png "Goldshirt")