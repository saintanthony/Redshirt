# Redshirt
Adds iconic Star Trek Redshirt suit to mod MoreSuits for Lethal Company
But because this mod did so well and because not everybody is cut out to be a Redshirt ;) I've added two more bonus suits!
Now you can have yourself an Away Team. ;)
Screenshots below! (Hopefully)
If you can't see the screenshots below go here: https://github.com/saintanthony/Redshirt#

<p align="center">
	<img src="https://cdn.discordapp.com/attachments/456306509266157599/1198139219718193254/redshirtpreview.png?ex=65bdd11a&is=65ab5c1a&hm=24679845db69d0dffafd9e29b1da6b8a9165810f2a5f70ad1d97c9d1e4ed845a&">
	<img src="https://media.discordapp.net/attachments/456306509266157599/1198139219227451482/blueshirtpreview.png?ex=65bdd11a&is=65ab5c1a&hm=71b389a2f84b745dc016e7ced6f1bac9f038baca43bb6fd58e2f0e156693620e">
	<img src="https://media.discordapp.net/attachments/456306509266157599/1198139219474927626/goldshirtpreview.png?ex=65bdd11a&is=65ab5c1a&hm=369d2d50bf4bf21d251a1b89d9d07bd6bf48d903644b1c6db21a314f755dd877">
</p>


[Redshirt](https://github.com/saintanthony/Redshirt/blob/main/redshirtpreview.png "Redshirt")
[Blueshirt]( https://github.com/saintanthony/Redshirt/blob/main/blueshirtpreview.png "Blueshirt")
[Goldshirt]( https://github.com/saintanthony/Redshirt/blob/main/goldshirtpreview.png "Goldshirt")