# Redshirt
Adds iconic Star Trek Redshirt suit to mod MoreSuits for Lethal Company
But because this mod did so well and because not everybody is cut out to be a Redshirt ;) I've added two more bonus suits!
Now you can have yourself an Away Team. ;)
Screenshots below! (Hopefully)
If you can't see the screenshots below go here: https://github.com/saintanthony/Redshirt#

<p align="center">
	<img src="https://www.dropbox.com/scl/fi/nu148gcxs41n0t12zpl3v/redshirtpreview.png?rlkey=ri7lss9oynfgticd8is62bkw3&dl=0" align="center">
	<img src="https://www.dropbox.com/scl/fi/ezymvdn6o4728730h3md2/blueshirtpreview.png?rlkey=znuqp91cw7dvbwgd0bgtcrxfp&dl=0" align="center">
	<img src="https://www.dropbox.com/scl/fi/1iwacwr8iizmtphskoue0/goldshirtpreview.png?rlkey=lzu0sxf5zx4hu29q5baprzpwv&dl=0" align="center">
</p>


![Redshirt]( https://github.com/saintanthony/Redshirt/blob/main/redshirtpreview.png "Redshirt")
![Blueshirt]( https://github.com/saintanthony/Redshirt/blob/main/blueshirtpreview.png "Blueshirt")
![Goldshirt]( https://github.com/saintanthony/Redshirt/blob/main/goldshirtpreview.png "Goldshirt")